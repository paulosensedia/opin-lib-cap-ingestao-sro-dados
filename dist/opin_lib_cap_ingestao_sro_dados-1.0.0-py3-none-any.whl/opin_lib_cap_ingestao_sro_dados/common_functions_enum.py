from enum import Enum


class CommonFunctionsEnum(Enum):
    CAMPOS_OBRIGATORIOS_PREENCHIDOS_INCORRETAMENTE = 'camposObrigatoriosPreenchidosIncorretamente'
    TAMANHO_CAMPO_INVALIDO = 'tamanhoCampoInvalido'
    OPCOES_PREENCHIMENTO_INVALIDO = 'opcoesPreenchimentoInvalido'